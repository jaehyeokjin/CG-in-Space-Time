# Log File Availability for error_bar_T380_L35.944
1. This folder uses the same log file used in ../T380_L35.944
2. To save space only contain the first (*_head) and last (*_tail) 1000 lines of the LAMMPS log files log.lammps log_2nd.lammps in ../T380_L35.944 fodler
3. The log files can be recreated using the LAMMPS scripts in.otp and in.otp_2nd (using data.initial), or referred to the separate log file (../../log-file/T380_L35.944/log.lammps)

