# Log File Availability for T380_L35.944
1. To save space this folder only contain the first (*_head) and last (*_tail) 1000 lines of the LAMMPS log files log.lammps log_2nd.lammps.
2. The log files can be recreated using the LAMMPS scripts in.otp and in.otp_2nd (using data.initial), or referred to the separate log file (../../log-file/T380_L35.944/log.lammps)
