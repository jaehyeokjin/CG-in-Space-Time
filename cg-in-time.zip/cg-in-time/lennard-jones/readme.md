# README for Lennard Jones folder

## Information
1. Materials in this folder is for the Supplemental Material regarding the extension to the Lennard-Jones (single-component) interaction
2. Detailed analysis can be obtained by running the lennard_jones.ipynb file

## Log File
Log files can be generated using the input and data file provided in this folder, or alternatively referred to ../../log-file/lennard-jones/
