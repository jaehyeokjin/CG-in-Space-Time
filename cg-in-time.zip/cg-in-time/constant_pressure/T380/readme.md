# Log file availabiltiy for constant_pressure
1. This folder only contains the first 1000 lines of the LAMMPS log file `log.otp` to save space.
2. The LAMMPS script `in.otp` will recreate this file (using `data.initial`)
3. Alternatively, the log file can be found in `log-file/constant_pressure/`
