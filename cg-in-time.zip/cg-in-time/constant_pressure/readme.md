# Calculate Prigogine-Defay ratio
1. Run 'analyse_npt.py' from T380 folder. This requires log file (../../log-file/constant_pressure/) and genetrates `thermo.csv'
   Alternatively, one can run in.* and data* file in LAMMPS to generate the same log file (to save the space)
2. From the generated `thermo.csv' run `plot_data.py'. This will generate the final figure file for the manuscript
